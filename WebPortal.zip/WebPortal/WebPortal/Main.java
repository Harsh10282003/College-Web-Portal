import java.util.Scanner;
class Main {
 public static void main(String[] args) {
 int temp;
 Scanner sc=new Scanner(System.in);
 System.out.print("\nEnter the array size:");
 int n=sc.nextInt();
 System.out.print("\nEnter the value of k:");
 int k=sc.nextInt();
 int a[]=new int[n];
 System.out.print("\nEnter the elements of array: ");
 for(int i=0;i<n;i++)
 a[i]=sc.nextInt();
 for(int i=0;i<n;i++)
 { for(int j=i+1;j<n;j++)
 { if(a[i]>a[j])
 { temp=a[i];
 a[i]=a[j];
 a[j]=temp;
 }
 }
 }
 for(int i=n-1;i>=n-k;i--)
 System.out.print(a[i]+" ");
 }
}
