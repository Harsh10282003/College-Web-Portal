Student Web Portal
How to run

1. Download the project zip file

2. Extract the file and copy WebPortal folder

3. Paste inside htdocs in XAMPP

4. Now open your MySQL command prompt

5. Create a database with the name   "webportal"

6. Copy and paste the file   "sql.txt"  inside MySQL command line client
   (given inside the zip package)

7. In every php file, change the MySQL password "himanshu" in the mysqli_connect query to your current database password

8. Run the script http://localhost/WebPortal/sign-in-form.php


Admin Credential
Username: harsh
Password: harsh